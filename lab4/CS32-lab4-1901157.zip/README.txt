
Group Name: CS32
Group Members:
-   Richa Singh : 1901157
-   Shantanu Raj : 1901183


## Contribution:

The individual contribution of the members were as follows:-
1.) Richa Singh - Implemented first and follow.
2.) Shantanu Raj - Implemented the elimination of left recursion.
The rest of the work like Reading the grammar, Building the LL1 predictive table, and Expression parsing were done in collaboration. 



